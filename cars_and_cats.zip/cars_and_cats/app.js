var http = require('http');
var fs = require('fs');
var server = http.createServer(function(req, res){
	console.log('client request URL:', req.url);

	if (req.url === "/cars"){
		fs.readFile('views/cars.html', 'utf8', function(err, contents){
			res.writeHead(200, {"Content-Type": 'text/html'});
			res.write(contents);
			res.end();
		})
		fs.readFile(`images/car1.png`, function(err, contents){
			res.writeHead(200, {"Content-Type": 'image/png'});
			res.write(contents);
			res.end();
		})
		fs.readFile(`images/car2.png`, function(err, contents){
			res.writeHead(200, {"Content-Type": 'image/png'});
			res.write(contents);
			res.end();
		})
		fs.readFile(`images/car3.png`, function(err, contents){
			res.writeHead(200, {"Content-Type": 'image/png'});
			res.write(contents);
			res.end();
		})
		fs.readFile('stylesheets/style.css', 'utf8', function(err, contents){
			res.writeHead(200, {"Content-Type": 'text/css'});
			res.write(contents);
			res.end();
		})
	} else if (req.url === "/cats") {
		fs.readFile('views/cats.html', 'utf8', function(err, contents){
			res.writeHead(200, {"Content-Type": "text/html"});
			res.write(contents);
			res.end();
		})
		fs.readFile(`images/cat1.png`, function(err, contents){
			res.writeHead(200, {"Content-Type": 'image/png'});
			res.write(contents);
			res.end();
		})
		fs.readFile(`images/cat2.png`, function(err, contents){
			res.writeHead(200, {"Content-Type": 'image/png'});
			res.write(contents);
			res.end();
		})
		fs.readFile(`images/cat3.png`, function(err, contents){
			res.writeHead(200, {"Content-Type": 'image/png'});
			res.write(contents);
			res.end();
		})
		fs.readFile('stylesheets/style.css', 'utf8', function(err, contents){
			res.writeHead(200, {"Content-Type": 'text/css'});
			res.write(contents);
			res.end();
		})
	} else if (req.url === '/car/new'){
		fs.readFile('views/new_car.html', 'utf8', function(err, contents){
			res.writeHead(200, {'Content-Type': 'text/html'});
			res.write(contents);
			res.end();
		})
		fs.readFile('stylesheets/style.css', 'utf8', function(err, contents){
			res.writeHead(200, {"Content-Type": 'text/css'});
			res.write(contents);
			res.end();
		})
	} else {
		res.writeHead(404);
		res.end('Page not found');
	}
})

server.listen(3000);
console.log("Running server at port 3000");
